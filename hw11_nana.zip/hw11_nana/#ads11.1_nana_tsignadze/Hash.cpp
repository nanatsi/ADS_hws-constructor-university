//CH-231-A.
//hw11 p1(b).cpp
//Nana Tsignadze
//Ntsignadze@jacobs-university.de

#include <iostream>
using namespace std;

class Node {
public:
    int key;
    int value;
    Node(int key, int value) {
        this->value = value;
        this->key = key;
    }
};

class HashTable {
private:
    Node** arr;
    int maxSize;
    int currentSize;
public:
    HashTable() {
        currentSize = 0;
        maxSize = 9;

        arr = new Node * [maxSize];

        //initializing each slot of the array to NULL
        for (int i = 0; i < maxSize; i++) {
            arr[i] = NULL;
        }
    }

    int hashCode(int key) {
        int position = key % maxSize;
        return position;
    }

    void insertNode(int key, int value) {
        if (currentSize >= maxSize)
            return;
        Node* mynode = new Node(key, value);

        int pos = hashCode(key);
        //finds the next available slot for insertion
        while (arr[pos] != nullptr) {
            pos = (pos + 1) % maxSize;
        }

        arr[pos] = mynode;
        currentSize++;
    }


    int get(int key) {

        int pos = hashCode(key);

        while (arr[pos] != nullptr && arr[pos]->key != key) {
            pos = (pos + 1) % maxSize; 
        }

        //in case key is found, return its value if not, return -1
        if (arr[pos] != nullptr && arr[pos]->key == key) {
            return arr[pos]->value;
        }
        else {
            return -1; 
        }
    }

    bool isEmpty() {
        return (currentSize == 0);
    }

    void print() {
        for (int i = 0; i < maxSize; i++) {

            if (arr[i] == NULL) {
                cout << "position " << i << " is empty! " << endl;
                cout << endl;
            }
            else {
                cout << "position: " << i << endl;
                cout << "the Key is: " << arr[i]->key << "\nthe Value is: ";
                cout << arr[i]->value << endl << endl;
            }
                        
        }
    }
};

int main() {
    HashTable hashtable; 
    hashtable.insertNode(11, 12);
    hashtable.insertNode(13, 14);
    hashtable.insertNode(15, 16);
    hashtable.insertNode(17, 18);
    hashtable.insertNode(19, 20);

    //printing the hash table
    cout << "Hash Table:" << endl;
    hashtable.print();
    cout << endl;

    //retrieving the value for key 13
    int value = hashtable.get(13);

    if (value != -1) {
        cout << "The value of key 13 is " << value << endl;
    }
    else {
        cout << "Key 13 not found in the hash table." << endl;
    }

    return 0;
}

