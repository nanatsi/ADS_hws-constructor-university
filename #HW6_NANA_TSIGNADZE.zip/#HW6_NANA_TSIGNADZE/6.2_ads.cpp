#include <iostream>
#include <chrono>

using namespace std;
using namespace std::chrono;

//heapifies our subtree rooted at the given index
void Max_Heapify(int A[], int size, int idx) {
    int largest;
    //indexes of a left and right child
    int leftChild = 2 * idx + 1;
    int rightChild = 2 * idx + 2; 

    //if left child is within the array bounds and greater than
    //  the current largest
    if ((A[leftChild] > A[idx]) && (leftChild < size)) {
        largest = leftChild;
    }
    else {
        largest = idx;
    }

    //checks whether the right child is within the array bounds and
    //  greater than the current largest
    if ((A[rightChild] > A[largest]) && (rightChild < size))
        largest = rightChild;
 
    //if the largest element is not root
    if (largest != idx) {
         swap(A[idx], A[largest]);

         //recursivey heapifies the sub-tre
         Max_Heapify(A, size, largest);
    }
}

 
void heapSort(int arr[], int size)
{
    //building a tree 
    for (int i = size / 2 - 1; i >= 0; i--)
        Max_Heapify(arr, size, i);

    //extracting elements from the heap 
    for (int i = size - 1; i >= 0; i--)
    {
        //the root now becomes the end 
        swap(arr[0], arr[i]);

        //using Max_Heapify on the smaller heap 
        Max_Heapify(arr, i, 0);
    }
}

int main() {

    double time_measure = 0;

    //inputting array
    cout << "enter the size of an array: ";
    int size;
    cin >> size;

    int* A = new int[size];
    cout << "now enter elements:\n";
    for (int i = 0; i < size; i++) {
        cin >> A[i];
    }

    auto start = high_resolution_clock::now();
    heapSort(A, size);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);
    cout << "execution time: " << duration.count() << " nanoseconds." << endl;


    //prints sorted array
    cout << "Sorted Array: ";
    for (int i = 0; i < size - 1; ++i) {
        cout << A[i] << ", ";
    }
    cout << A[size - 1] << ".\n";

    delete A;

    return 0;
}