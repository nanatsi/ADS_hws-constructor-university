//CH-231-A.
//hw11 p2(b).cpp
//Nana Tsignadze
//Ntsignadze@jacobs-university.de

#include <iostream>
#include <algorithm>

using namespace std;

struct Activity {
    int start;
    int finish;
};

void greedy_algorithm(Activity arr[], int n) {

    //sorts activities based on start time in descending order
    sort(arr, arr + n, [](const Activity& a, const Activity& b) {
        return a.start > b.start;
        });

    //starting with the first activity
    int latestFinish = arr[0].finish;
    cout << arr[0].start << " - " << arr[0].finish << endl;

    //iterating over the remaining activities
    for (int i = 1; i < n; i++) {
        //checks if the current activity can be selected
        if (arr[i].finish <= latestFinish) {
            cout << arr[i].start << " - " << arr[i].finish << endl;
            //update the latest finish time
            latestFinish = arr[i].finish;
        }
    }
}

int main() {

    Activity arr[] = { {1, 3}, {0, 12}, {5, 9}, {11, 15} };
    int n = sizeof(arr) / sizeof(arr[0]);

    cout << "Selected activities: " << endl;

    greedy_algorithm(arr, n);

    return 0;
}
