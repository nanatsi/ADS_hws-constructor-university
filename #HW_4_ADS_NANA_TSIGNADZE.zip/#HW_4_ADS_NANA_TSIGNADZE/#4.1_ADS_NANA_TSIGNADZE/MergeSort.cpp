//CH-231-A.
//hw4 p1(a,b,c,d).cpp
//Nana Tsignadze
//Ntsignadze@jacobs-university.de

#include <iostream>
#include<chrono>
using namespace std::chrono;

using namespace std;

//insertion sort func
void insertion_sort(int arr[], int const begin, int const end) {
    int i, j, key;

    for (i = begin + 1; i <= end; i++) {
        key = arr[i];
        j = i - 1;

        while (j >= begin && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }

        arr[j + 1] = key;
    }
}
// Merges two subarrays of array[].
// First subarray is arr[begin-mid]
// Second subarray is arr[mid+1-end] 
void merge(int array[], int const left, int const mid,
    int const right)
{
    int const Quantityleft = mid - left + 1;
    int const Quantityright = right - mid;

    //creates temp arrays
    auto* leftArray = new int[Quantityleft],
        * rightArray = new int[Quantityright]; 

    //copies data to temp arrays leftTempArray[] and rightTempArray[]
    for (auto i = 0; i < Quantityleft; i++)
        leftArray[i] = array[left + i];
    for (auto j = 0; j < Quantityright; j++)
        rightArray[j] = array[mid + 1 + j];

    auto R = 0, L = 0;
    int indexMerged = left;

    //merge the temp arrays back into array[left-right]
    while (L < Quantityleft && R < Quantityright) {
        if (leftArray[L]
            <= rightArray[R]) {
            array[indexMerged]
                = leftArray[L]; 
            L++; 
        }
        else {
            array[indexMerged]
                = rightArray[R];
            R++;
        }
        indexMerged++;
    }

    //copies the remaining elements of
    //leftTempArray[], if there are any
    while (L < Quantityleft) {
        array[indexMerged]
            = leftArray[L];
        L++;
        indexMerged++;
    }

    //copies the remaining elements of
    //rightTempArray[], if there are any
    while (R < Quantityright) {
        array[indexMerged]
            = rightArray[R];
        R++;
        indexMerged++;
    }
    delete[] leftArray;
    delete[] rightArray;
}

void new_merge(int arr[], int const begin, int const end, int k) {
    int mid, key;
    //until we reach k, program uses the merging sort
    if (end - begin > k) {
        mid = begin + (end - begin) / 2;
        new_merge(arr, begin, mid, k);
        new_merge(arr, mid + 1, end, k);
        merge(arr, begin, mid, end);
    } else {
        //when we have k-k, program starts insertion sort
        insertion_sort(arr, begin, end);
    }
}

int main() {
    int n;

    //get the size
    cout << "Size of the array: ";
    cin >> n;

    //creates array of size n
    int* arr = new int[n];

    //Get array elements from the user
    cout << "the elements of the array: " << endl;
    for (int i = 0; i < n; ++i) {
        cout << "element " << i + 1 << ": ";
        cin >> arr[i];
    }
	
	//b)
    //quantity of the different values of K
    int num;
    cout << "quantity of K cases: ";
    cin >> num;

    int* k = new int[num];

    //gets the values of k
    cout << "values of k: ";

    for (int i = 0; i < num; i++) {
        cin >> k[i];

        //starts measuring time
        auto start_time = high_resolution_clock::now();

        //performs sorting
        new_merge(arr, 0, n - 1, k[i]);

        //ends measuring
        auto end_time = high_resolution_clock::now();

        //shows the execution time
        auto duration = duration_cast<microseconds>(end_time - start_time);
        cout << "Execution Time: " << duration.count() << " microseconds" << endl;

    }
    
     //outputs the sorted array
    for (int j = 0; j < n; ++j) {
        cout << arr[j] << " ";
    }
    cout << endl;

    //deallocation
    delete[] k;
    delete[] arr;

    return 0;
}

/*
C)

BEST CASE:
The best case occurs when our array is nearly sorted and K is comparably small number. In such situation,
insertion sort is handling small disorder and the execution time is minimal.

AVERAGE CASE:
The choice of K now depends on the expected level of disorder. Meaning, if our array is not perfectly sorted, nor mess,
in this "average" case, we want to find a number that helps keep things organized without adding too much extra work.
If our K is too small in that case, the additional work of using insertion sort too often might just slow things down.
On the other hand, we don't want to pick k too large either. If it's too big, insertion sort might not be as efficient at
handling smaller groups of numbers. In summary, we want to look for "just right", middle-ground K depending on the size of 
array.

WORST CASE:
When we have the absolute disorder, picking large K might helpful. Meaning, there's a bigger chance
that the sides which are left, n/k is relatively small (the length of subarrays) and then insertion sort
has less mess to handle, which obviously takes much less time. But we don't want to take K too big so that the usage of
insertion sort doesn't loose efficiancy sorting extremely small groups.


D)

if my array is nearly sorted, I'd choose comparabely small K speaking from the perspective of arguments mentioned in my best case.
The larger and messier my array gets the lager K I choose, but that requires careful consideration. we don't want to lose efficiency
so we maximally reduce the frequency of applying insertion sort and at the same time let the merge sort see to bigger subbarays which 
overall decreases extra work.

 */


