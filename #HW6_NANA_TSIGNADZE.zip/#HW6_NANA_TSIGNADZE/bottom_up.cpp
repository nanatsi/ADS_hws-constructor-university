#include <iostream>
#include <chrono>

using namespace std;
using namespace std::chrono;

void sink(int A[], int start, int end) {
    int root = start;
    //while root has at least one child
    while (2 * root + 1 <= end) {
        int leftChild = 2 * root + 1; 
        int rightChild = leftChild + 1;  
        int idx = root;

        //finds the larger child
        if (A[idx] < A[leftChild]) {
            idx = leftChild;
        }

        if (rightChild <= end && A[idx] < A[rightChild]) {
            idx = rightChild;
        }
        //if root isn't larger 
        if (idx != root) {
            //swaps
            swap(A[root], A[idx]);
            //updting root to continiu seeking
            root = idx;       
        }
        else {
            return;
        }
    }
}

//turning A into max heap
void buildMaxHeap(int A[], int size) {
    //starts sinking nodes from non-leaf node
    for (int start = (size / 2) - 1; start >= 0; start--) {
        sink(A, start, size - 1);
    }
}

void heapSort(int A[], int size) {
    //calling buildmax
    buildMaxHeap(A, size);
    int end = size - 1;
    while (end > 0) {
        //moves max element to the end of the array
        std::swap(A[0], A[end]);
        //decreamenting size
        end--;
        //restoring heap property
        sink(A, 0, end);
    }
}

int main() {

    //inputting array
    cout << "enter the size of an array: ";
    int size;
    cin >> size;

    int* A = new int[size];
    cout << "now enter elements:\n";
    for (int i = 0; i < size; ++i) {
        cin >> A[i];
    }

    auto start = high_resolution_clock::now();
    heapSort(A, size);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);


    //prints sorted array
    cout << "Sorted Array: ";
    for (int i = 0; i < size - 1; ++i) {
        cout << A[i] << ", ";
    }
    cout << A[size - 1] << ".\n";

    cout << "Execution time: " << duration.count() << " nanoseconds." << endl;

    delete A;

    return 0;
}