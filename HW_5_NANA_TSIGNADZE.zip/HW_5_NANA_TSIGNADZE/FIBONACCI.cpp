//CH-231-A.
//hw5 p1.cpp
//Nana Tsignadze
//Ntsignadze@jacobs-university.de

#include <iostream>
#include <cmath>
#include <chrono>
#include <iomanip>
#include <functional>

using namespace std;
using namespace chrono;

//naive recursive as discussed
int naive_recursive(int n) {
    if (n < 2) {
        return n;
    } else {
        return naive_recursive(n - 1) + naive_recursive(n - 2);
    }
}
//bottom up func
int bottom_up(int n) {
    int* arr = new int[n + 1];
    arr[0] = 0;
    arr[1] = 1;

    for (int i = 2; i <= n; i++) {
        arr[i] = arr[i - 1] + arr[i - 2];
    }

    int fib = arr[n];

    delete[] arr;
    return fib;
}
//closed form
int closed_form(int n) {
    float num1 = (1 + sqrt(5)) / 2;
    float num2 = (1 - sqrt(5)) / 2;

    return (pow(num1, n) - pow(num2, n)) / sqrt(5);
}

//forward declaration for power function
void power(int F[2][2], int n);
void multiply(int F[2][2], int M[2][2]);
void fib_matrix(int n, int F[2][2]); 


void power(int F[2][2], int n) {
    if (n == 0 || n == 1)
        return;
    int M[2][2] = {{1, 1}, {1, 0}};

    power(F, n / 2);
    multiply(F, F);

    if (n % 2 != 0)
        multiply(F, M);
}
//multiplication func
void multiply(int F[2][2], int M[2][2]) {
    int x = F[0][0] * M[0][0] + F[0][1] * M[1][0];
    int y = F[0][0] * M[0][1] + F[0][1] * M[1][1];
    int z = F[1][0] * M[0][0] + F[1][1] * M[1][0];
    int w = F[1][0] * M[0][1] + F[1][1] * M[1][1];

    F[0][0] = x;
    F[0][1] = y;
    F[1][0] = z;
    F[1][1] = w;
}

void fib_matrix(int n, int F[2][2]) {
    if (n == 0)
        return;
    power(F, n);
}

using FibonacciFunction = function<int(int)>;
//creating an array of fibonacci funcs
FibonacciFunction fibonacciFunctions[] = {
    naive_recursive,
    bottom_up,
    closed_form
};
//time measuring func
void time_count(FibonacciFunction fibFunc, int number) {
    auto start = high_resolution_clock::now();
    unsigned long long result = fibFunc(number);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);
    cout << " " << duration.count() << " ";
}

const int nums[] = {0, 1, 2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 32, 40, 50, 63};
const int size = sizeof(nums) / sizeof(nums[0]);

int main() {
    cout << "naive|bottomup|closedform|matrix|" << endl;

    for (int i = 0; i < size; i++) {
        int n = nums[i];
        
        cout << n;
        //using myfunction to determine times
        //in each cases
        for (const auto &fibFunc : fibonacciFunctions) {
            time_count(fibFunc, n);
        }

        //matrix representation
        int F[2][2] = {};
        auto start = high_resolution_clock::now();
        fib_matrix(n, F);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<nanoseconds>(stop - start);
        cout << duration.count() << endl;
    }

    return 0;
}
